public class Attendee {
    String name;
    int age;
    String mobile;
    int seatNumber;

    public Attendee(String name, int age, String mobile, int seatNumber) {
        this.name = name;
        this.age = age;
        this.mobile = mobile;
        this.seatNumber = seatNumber;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getMobile() {
        return mobile;
    }

    public int getSeatNumber() {
        return seatNumber;
    }
}
