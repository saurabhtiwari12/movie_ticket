import java.util.*;

public class BookingManager {
    public static final int TOTAL_SEATS = 30;
    private HashMap<Integer, Attendee> bookings;

    public BookingManager() {
        bookings = new HashMap<>();
    }

    public Attendee bookSeat(String name, int age, String mobile) {
        for (int i = 1; i <= TOTAL_SEATS; i++) {
            if (!bookings.containsKey(i)) {
                Attendee attendee = new Attendee(name, age, mobile, i);
                bookings.put(i, attendee);
                return attendee;
            }
        }
        throw new RuntimeException("All seats are booked!");
    }

    public boolean isSeatBooked(int seat) {
        return bookings.containsKey(seat);
    }

    public Attendee getAttendeeAtSeat(int seat) {
        return bookings.get(seat);
    }

    public List<Attendee> getAllAttendees() {
        return new ArrayList<>(bookings.values());
    }
}
