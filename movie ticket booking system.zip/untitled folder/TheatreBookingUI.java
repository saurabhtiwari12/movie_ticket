import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class TheatreBookingUI extends JFrame {
    private BookingManager manager = new BookingManager();

    private JTextField nameField, ageField, mobileField;
    private JTextArea ticketArea;
    private JTable attendeeTable;
    private DefaultTableModel tableModel;
    private JPanel seatsPanel;

    public TheatreBookingUI() {
        setTitle("Arjit Singh Special - Show Booking");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        add(createInputPanel(), BorderLayout.WEST);
        add(createStatusPanel(), BorderLayout.CENTER);

        updateSeats();
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setPreferredSize(new Dimension(300, 500));
        panel.setBorder(BorderFactory.createTitledBorder("Book Your Seat"));
    
        JPanel form = new JPanel(new GridLayout(7, 2, 5, 10));
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
        form.add(new JLabel("Name:"));
        nameField = new JTextField();
        form.add(nameField);
    
        form.add(new JLabel("Age:"));
        ageField = new JTextField();
        form.add(ageField);
    
        form.add(new JLabel("Mobile:"));
        mobileField = new JTextField();
        form.add(mobileField);
    
        // Extra Info - Show name, time, and price
        form.add(new JLabel("Show:"));
        form.add(new JLabel("Arjit Singh Special"));
    
        form.add(new JLabel("Time:"));
        form.add(new JLabel("7:00 PM"));
    
        form.add(new JLabel("Price:"));
        form.add(new JLabel("Rs. 1000"));
    
        JButton bookBtn = new JButton("Book Now");
        bookBtn.addActionListener(e -> bookSeat());
    
        ticketArea = new JTextArea(10, 25);
        ticketArea.setEditable(false);
        JScrollPane ticketPane = new JScrollPane(ticketArea);
        ticketPane.setBorder(BorderFactory.createTitledBorder("Your Ticket"));
    
        panel.add(form);
        panel.add(bookBtn);
        panel.add(ticketPane);
        return panel;
    }
    

    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        seatsPanel = new JPanel(new GridLayout(5, 6, 5, 5));
        seatsPanel.setBorder(BorderFactory.createTitledBorder("Seat Status"));

        String[] cols = {"Seat", "Name", "Age", "Mobile"};
        tableModel = new DefaultTableModel(cols, 0);
        attendeeTable = new JTable(tableModel);
        JScrollPane tablePane = new JScrollPane(attendeeTable);
        tablePane.setBorder(BorderFactory.createTitledBorder("All Bookings"));

        panel.add(seatsPanel, BorderLayout.NORTH);
        panel.add(tablePane, BorderLayout.CENTER);
        return panel;
    }

    private void updateSeats() {
        seatsPanel.removeAll();

        for (int i = 1; i <= BookingManager.TOTAL_SEATS; i++) {
            JButton btn = new JButton("Seat " + i);
            if (manager.isSeatBooked(i)) {
                btn.setBackground(Color.RED);
                btn.setForeground(Color.WHITE);
                btn.setText("Booked");
                int seatNo = i;
                btn.addActionListener(e -> {
                    Attendee a = manager.getAttendeeAtSeat(seatNo);
                    JOptionPane.showMessageDialog(this,
                            "Seat: " + seatNo + "\nName: " + a.getName() +
                            "\nAge: " + a.getAge() + "\nMobile: " + a.getMobile(),
                            "Booking Details", JOptionPane.INFORMATION_MESSAGE);
                });
            } else {
                btn.setBackground(Color.GREEN);
            }
            seatsPanel.add(btn);
        }
        seatsPanel.revalidate();
        seatsPanel.repaint();
    }

    private void bookSeat() {
        String name = nameField.getText().trim();
        String ageStr = ageField.getText().trim();
        String mobile = mobileField.getText().trim();

        if (name.isEmpty() || ageStr.isEmpty() || mobile.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int age = Integer.parseInt(ageStr);
            Attendee attendee = manager.bookSeat(name, age, mobile);
            showTicket(attendee);
            updateSeats();
            updateTable();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Age must be a number", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Booking Failed", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void showTicket(Attendee a) {
        StringBuilder sb = new StringBuilder();
        sb.append("====== SHOW TICKET ======\n");
        sb.append("Show: Arjit Singh Special\n");
        sb.append("Time: 7:00 PM\n");
        sb.append("Seat No: ").append(a.getSeatNumber()).append("\n");
        sb.append("Name: ").append(a.getName()).append("\n");
        sb.append("Age: ").append(a.getAge()).append("\n");
        sb.append("Mobile: ").append(a.getMobile()).append("\n");
        sb.append("Price: Rs. 1000\n");
        sb.append("=========================\n");

        ticketArea.setText(sb.toString());
    }

    private void updateTable() {
        tableModel.setRowCount(0);
        List<Attendee> list = manager.getAllAttendees();
        for (Attendee a : list) {
            tableModel.addRow(new Object[]{a.getSeatNumber(), a.getName(), a.getAge(), a.getMobile()});
        }
    }
}
